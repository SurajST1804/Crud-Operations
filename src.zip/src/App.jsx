import React from "react";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home";
import Navbar from "./Pages/Navbar";
// import CreatePosts from "./Components/CreatePosts";
// import DeletePost from "./Components/DeletePost";
// import EditPost from "./Components/EditPost";
// import Home from "./Pages/Home";
// import Navbar from "./Pages/Navbar";

import CreatePosts from "./reducer/CreatePost";
import DeletePost from "./reducer/DeletePost";
import EditPost from "./reducer/EditPost";

const App = () => {
  return (
    <Router>
      <section>
        <header>
          <Navbar />
        </header>
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/create-post" element={<CreatePosts />} />
            <Route path="/edit-post/:id" element={<EditPost />} />
            <Route path="/delete-post/:id" element={<DeletePost />} />
          </Routes>
        </main>
        <footer></footer>
      </section>
    </Router>
  );
};

export default App;
