export let AddPost = () => {
  return {
    type: "ADDPOST",
  };
};

export let DeletePost = () => {
  return {
    type: "DELETEPOST",
  };
};

export let UpdatePost = () => {
  return {
    type: "UPDATEPOST",
  };
};
