let ReducerComp = (state, action) => {
  import CreatePosts from "../reducer/CreatePost";
  import DeletePost from "../reducer/DeletePost";
  import EditPost from "../reducer/EditPost";
  switch (action.type) {
    case "ADDPOST":
      return <CreatePosts />;

    case "DELETEPOST":
      return <DeletePost />;

    case "UPDATEPOST":
      return <EditPost />;

    default:
      return state;
  }
};

export default ReducerComp;
