import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Axios from "../Axios";

const EditPost = () => {
  let navigate = useNavigate();
  let { id } = useParams();
  let [state, setState] = useState({
    title: "",
    author: "",
    loading: false,
  });

  let { title, author, loading } = state;

  //   let { id } = useParams();
  useEffect(() => {
    let fetchPosts = async () => {
      let existData = await Axios.get(`/posts/${id}`);
      console.log(existData.data);
      setState(existData.data);
    };
    fetchPosts();
  }, [id]);

  let handleChange = (e) => {
    let { name, value } = e.target;
    setState({ ...state, [name]: value });
  };

  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setState({ loading: true });
      let payload = { title, author };
      await Axios.put(`/posts/${id}`, payload);
      navigate("/");
      //   console.log({ title, author });
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <section id="postsBlock" className="col-md-4 mx-auto bg-white p-4 mt-4">
      <article>
        <h2 className="h4 font-weight">Update posts</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="exampleInputEmail1" className="form-label">
              title
            </label>
            <input
              type="text"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              name="title"
              value={title}
              onChange={handleChange}
            />
            {/* <div id="emailHelp" className="form-text">
            We'll never share your email with anyone else.
          </div> */}
          </div>
          <div className="mb-3">
            <label htmlFor="exampleInputPassword1" className="form-label">
              author
            </label>
            <input
              type="text"
              className="form-control"
              id="exampleInputPassword1"
              name="author"
              value={author}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary">
            Update
          </button>
        </form>
      </article>
    </section>
  );
};

export default EditPost;
