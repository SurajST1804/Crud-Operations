import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Axios from "../Axios";
const DeletePost = () => {
  let navigate = useNavigate();
  let { id } = useParams();

  let [state, setState] = useState({
    title: "",
    author: "",
    loading: false,
  });

  let { title, author, loading } = state;

  useEffect(() => {
    let fetchData = async () => {
      let deleteData = await Axios.get(`/posts/${id}`);
      console.log(deleteData.data);
      setState(deleteData.data);
    };
    fetchData();
  }, [id]);

  let handleChange = (e) => {
    let { name, value } = e.target;
    setState({ ...state, [name]: value });
  };

  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setState({ loading: true });
      let payload = { title, author };
      await Axios.delete(`/posts/${id}`, payload);
      navigate("/");
      //   console.log({ title, author });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    // <section id="postsBlock" className="col-md-4 mx-auto bg-white p-4 mt-4">
    //   <article>
    //     <h2 className="h4 font-weight">Delete posts</h2>
    //     <form onSubmit={handleSubmit}>
    //       <button type="submit" className="btn btn-primary">
    //         Delete
    //       </button>
    //     </form>
    //   </article>
    // </section>
    <div>
      <aside>
        <div className="float-left">
          <h2 className="h4">
            {title}
            <span className="text-success">{author}</span>
          </h2>
        </div>
        <div className="float-right">
          <button className="btn btn-danger" onClick={handleSubmit}>
            Delete
          </button>
        </div>
      </aside>
    </div>
  );
};

export default DeletePost;
