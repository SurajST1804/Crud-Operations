import { combineReducers } from "redux";
import CreatePosts from "./../../src1/Components/CreatePosts";
import ReducerComp from "./ReducerComp";
import DeletePost from "./../../src1/Components/DeletePost";
import EditPost from "./../../src1/Components/EditPost";

let reducer = combineReducers({
  ReducerComp,
  CreatePosts,
  DeletePost,
  EditPost,
});

export default reducer;
